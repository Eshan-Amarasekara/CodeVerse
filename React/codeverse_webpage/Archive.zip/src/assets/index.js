
import logo from "./logo.png";
import robot from "./robot.png";
import send from "./Send.svg";
import shield from "./Shield.svg";
import star from "./Star.svg";
import menu from "./menu.svg";
import close from "./close.svg";
import arrowUp from "./arrow-up.svg";
import facebook from "./facebook.svg";
import instagram from "./instagram.svg";
import linkedin from "./linkedin.svg";
import twitter from "./twitter.svg";
import quotes from "./quotes.svg";
import textcommand from "./text-command.svg";
import brush from "./brush.svg";

export {
  logo,
  robot,
  send,
  shield,
  star,
  menu,
  close,
  arrowUp,
  facebook,
  instagram,
  linkedin,
  twitter,
  quotes,
  textcommand,
  brush
};
